package guru.springframework.msscbrewary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsscBrewaryApplicationTests {

	@Test
	void contextLoads() {
	}

}
