package guru.springframework.msscbrewary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsscBrewaryApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsscBrewaryApplication.class, args);
	}

}
